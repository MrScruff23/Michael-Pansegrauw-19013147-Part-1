﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1
{
    /*
protected int xPos = 0;
protected int yPos = 0;
protected int health;
protected int maxHealth;
protected int attack;
protected int attackRange;
protected int team;
protected bool isAttacking;
*/
    class MeeleeUnit: Unit
    {
        public MeeleeUnit(int xPos, int yPos, double maxHealth, double attack, int speed, int team)
        {
            base.xPos = xPos;
            base.yPos = yPos;
            base.maxHealth = maxHealth;
            base.health = maxHealth;
            base.attack = attack;
            base.team = team;
            base.speed = speed;
            base.attackRange = 1;
            base.isAttacking = false;
            base.symbol = "O";
        }

        public override void Move(Direction d, int distance) // handles the movement o the unit
        {
            if (distance > speed)
                distance = speed;
            switch (d)
            {
                case Direction.Up:
                    if (yPos - distance >= 0)
                    {
                        yPos -= distance;
                    }
                    else
                    {
                        yPos = 0;
                    }
                    break;
                case Direction.Down:
                    if (yPos + distance < 20)
                    {
                        yPos+= distance;
                    }
                    else
                    {
                        yPos = 19;
                    }
                    break;
                case Direction.Left:
                    if (xPos - distance >= 0)
                    {
                        xPos -= distance;
                    }
                    else
                    {
                        xPos = 0;
                    }
                    break;
                case Direction.Right:
                    if (xPos + distance < 20)
                    {
                        xPos += distance;
                    }
                    else
                    {
                        xPos = 19;
                    }
                    break;
                default:
                    break;
            }
        }
        
        public override bool DestroyUnit() // handles destruction and death of unit
        {
            if (health <= 0)
            {
                symbol = "X";
                return true;
            }
            return false;
        }

        public override string ToString() // displays unit information in a neat format
        {
            try
            {
                string s = string.Format(
                    "Position (x, y): (" + xPos + ", " + yPos + ")" +
                    "\nHealth\\MaxHealth : " + health + "\\" + maxHealth + 
                    "\nAttack : " + attack + 
                    "\nAttack Range : " + attackRange + 
                    "\nTeam : " + team + 
                    "\nIs attacking : " + isAttacking);
                return s;
            }
            catch (Exception ex)
            {
                return "Error Formating ToString :\n" + ex;
            }
        }

        public override void Combat(double damage)
        {
            health -= damage;
        }

        public override bool IsInRange(Unit u)
        {
            int distance = Convert.ToInt32(Math.Sqrt(Math.Pow((u.xPos - xPos), 2) + Math.Pow((u.yPos - yPos), 2))); // using pythagorus to deturmin the distance the unit is
            return (distance <= attackRange)? true: false;
        }

        public override Unit FindClosestUnit(List<Unit> listOfUnits)
        {
            int distance = -1;
            Unit enemy = null;
            foreach (Unit u in listOfUnits)
            {
                if (u.team != team)
                {
                    int temp = Convert.ToInt32(Math.Sqrt(Math.Pow((u.xPos - xPos), 2) + Math.Pow((u.yPos - yPos), 2)));
                    if (temp >= distance)
                    {
                        distance = temp;
                        enemy = u;
                    }
                }
            }
            return enemy;
        }

        public override Direction DirectionOfEnemy(Unit enemy)
        {
            int xdis = enemy.xPos - xPos;
            int ydis = enemy.yPos - yPos;
            if (Math.Abs(xdis) > Math.Abs(ydis))
            {
                if (xdis > 0)
                {
                    return Direction.Right;
                }
                else
                {
                    return Direction.Left;
                }
            }
            else
            {
                if (ydis > 0)
                {
                    return Direction.Down;
                }
                else
                {
                    return Direction.Up;
                }
            }
        }
    }
}
