﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_1
{
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }
    abstract class Unit
    {
        public int xPos = 0;
        public int yPos = 0;
        public double health;
        public double maxHealth;
        public double attack;
        protected int speed;
        protected double attackRange;
        public int team;
        public string symbol;
        public bool isAttacking;

        public abstract void Move(Direction d, int distance); // handles the movement of the unit
        public abstract void Combat(double damage); // handles the combat of the unit
        public abstract bool IsInRange(Unit u); // deturmins if a unit is in range for the unit to attack
        public abstract Unit FindClosestUnit(List<Unit> listOfUnits); // closest position to another unit; each co-ordinate will be separated by a semi-colon ";" and is going to be stored in the form of a string
        public abstract bool DestroyUnit(); // handles destruction and death of unit
        public abstract override string ToString(); // displays unit information in a neat format
        public abstract Direction DirectionOfEnemy(Unit enemy);
    }
}
